import React from 'react'
//import ReactDOM from 'react-dom';
import { Icon } from '@zambezi/sdk/icons'
import './App.css'

import Footer from './component/footer/index';
//import Counter from './container/counterContainer';
import Mainform from './component/forms/mainform';


class App extends React.Component {
  render() {
  return (
    <div className='App'>
      <header className='zb-masthead-container'>
        <div className='zb-masthead App-masthead'>
          <span className='zb-masthead-brand-logo' />
          <span className='zb-masthead-brand-name'>VCG team smart form replacement</span>
          <nav className='zb-masthead-nav'>
          
            <a
              href='http://websdk.rbsgrp.net/?path=/story/sdk-masthead--basic'
              className='zb-masthead-nav-item zb-button-with-icon-after'
            >
              Components <Icon name='customise-small' />
            </a>
            <a
              href='http://websdk.rbsgrp.net/?path=/story/documentation--getting-started'
              className='zb-masthead-nav-item zb-button-with-icon-after'
            >
              Documentation <Icon name='document-small' />
            </a>
            <a
              href='http://websdk.rbsgrp.net/?path=/story/introduction--faqs'
              className='zb-masthead-nav-item zb-button-with-icon-after'
            >
              FAQs <Icon name='help-xsmall' />
            </a>
            <a
              href='http://websdk.rbsgrp.net/?path=/story/introduction--support'
              className='zb-masthead-nav-item zb-button-with-icon-after'
            >
              Support <Icon name='edit-xsmall' />
            </a>
          </nav>
        </div>
      </header>
      <main className='App-main'>
        <section className='zb-card'>
          <header className='zb-card-header'>
            <h1 className='zb-card-header-title'>
              VCG Smart form
            </h1>
            <Mainform></Mainform>
          </header>
          {/* <div className='zb-card-body'>
            <p>
              <strong>WebSDK Starter App</strong> is a{' '}
              <abbr title='Single Page Application'>SPA</abbr> template built
              using the <a href='https://websdk.rbsgrp.net/'>WebSDK</a>,{' '}
              <a href='http://websdk.rbsgrp.net/?path=/story/formidable-components-formidable--basic'>
                Formidable
              </a>{' '}
              and{' '}
              <a href='http://websdk.rbsgrp.net/?path=/story/formidable-components-inputfield--basic'>
                Formidable Components
              </a>{' '}
              with{' '}
              <a href='https://facebook.github.io/create-react-app/'>
                Create React App
              </a>
              .
            </p>
            <h2 className='zb-heading2'>Customisation</h2>
            <p>This is a sample application. You will need to update:</p>
            <ul className='zb-list'>
              <li>
                the application <code>name</code> and <code>short_name</code> in{' '}
                <code>public/manifest.json</code>,
              </li>
              <li>
                change the <code>&lt;title&gt;</code> in{' '}
                <code>public/index.html</code>,
              </li>
              <li>
                swap <code>public/favicon.ico</code>,
              </li>
              <li>
                and replace <code>src/App.js</code> with your own application.
              </li>
            </ul>
            <p>
              To change the theme of the application, you will need to update:
            </p>
            <ul className='zb-list'>
              <li>
                the <code>class</code> on the <code>body</code> in{' '}
                <code>public/index.html</code>,
              </li>
              <li>
                change the imported <code>icon</code> set and{' '}
                <code>theme.min.css</code> path in <code>src/index.js</code>
              </li>
            </ul>
          </div>
        </section>
        <section className='zb-card'>
          <header className='zb-card-header'>
            <h2 className='zb-card-header-title'>Sign up</h2>
          </header>
          <div className='zb-card-body'>
            <Signup />
          </div> */}
        </section>
      </main>
      <Footer></Footer>
    </div>
  )
}
}

export default App
