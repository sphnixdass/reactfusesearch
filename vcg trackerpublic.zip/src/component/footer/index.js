
import React from 'react';

class Footer extends React.Component {
  render() {
    return (
    
    <footer className='zb-footer' role='contentinfo'>
        <div className='App-footer'>
          <span className='zb-footer-text'>© 2020 WebSDK</span>
        </div>
      </footer>
    )
    
  }
}

export default Footer