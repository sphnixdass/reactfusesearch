import React, { Component } from 'react';
import { connect } from 'react-redux'
//import Counter from '../component/counter'
import { increment, decrement, reset, textbox } from '../../actions';
import { SelectField } from '@zambezi/formidable-components';

import PersonalForm from './personalform';
import DisplayResult from './displayResult';

const mapStateToProps = (state) => {
   return {
    storeState: state
   };
};


const mapDispatchToProps = (dispatch) => {
   //console.log("counter ")
   return {
      textbox: (val) => {console.log("counter ", val) ; dispatch(textbox(val))},
      increment: (val) => {console.log("counter", val) ; dispatch(increment(val))},
      decrement: () => dispatch(decrement()),
      reset: () => dispatch(reset()),
   };
};



class Mainform extends Component {
    
   render() {
      const {storeState, textbox} = this.props;
      return (
         <div>
             <div className='zb-container'>
                <div className='zb-columns'>
                    <SelectField
                name={"name"}
                value={""}
                label={"Select the form type"}
                hint={"Select the form type"}
                values={[
                    {
                            "label": "Personal Form",
                            "value": "PersonalForm"
                    },
                    {
                            "label": "Sample Form",
                            "value": "SampleForm"
                    },
                    {
                     "label": "Generate Report",
                     "value": "Result"
                     },
                    {
                            "label": "N/A",
                            "value": "3"
                    }
            ]}
                onChange= {(id, value) => textbox(value)}
                onFocus={console.log.bind(console, "focused")}
                onBlur={console.log.bind(console, "blurred")}
                />
        </div>
    </div>

            {storeState.textbox === "PersonalForm"? <PersonalForm></PersonalForm> : ""}
            {storeState.textbox === "Result"? <DisplayResult></DisplayResult> : ""}
           
           
         </div>
      );
   }
}
export default connect(mapStateToProps, mapDispatchToProps)(Mainform);
