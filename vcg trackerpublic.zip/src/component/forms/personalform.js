import React, { Component } from 'react';
import { connect } from 'react-redux'
//import Counter from '../component/counter'
import { pffirstname, pflasttname, pfemailid, pfcommants, pfsubmit } from '../../actions';
import { InputField } from '@zambezi/formidable-components';


const mapStateToProps = (state) => {
   return {
    storeState: state
   };
};


const mapDispatchToProps = (dispatch) => {
   console.log("counter ")
   return {
      pffirstname: (val) => dispatch(pffirstname(val)),
      pflasttname: (val) => dispatch(pflasttname(val)),
      pfemailid: (val) => dispatch(pfemailid(val)),
      pfcommants: (val) => dispatch(pfcommants(val)),
      pfsubmit: () => dispatch(pfsubmit()),
    
   };
};



class PersonalForm extends Component {
     
   render() {
      const {storeState, pffirstname, pflasttname, pfemailid, pfcommants, pfsubmit} = this.props;
      return (
         <div>
            <div className='zb-container'>
               <div className='zb-columns'>
                  <div className='zb-column-is-6'>
                     <InputField
                        name={"pffirstname"}
                        id="pffirstname"
                        label={"Enter First Name"}
                        required={true}
                        hint={"Enter firstname"}
                        onChange = {(id, value) => pffirstname(value)}
                        value={storeState.pffirstname }
                     />

                  </div>

                  <div className='zb-column-is-6'>
                     <InputField
                        name={"pflasttname"}
                        id="pflasttname"
                        label={"Enter Last Name"}
                        hint={"Enter lastname"}
                        onChange = {(id, value) => pflasttname(value)}
                        value={storeState.pflasttname }
                     />

                  </div>

               </div>

               <div className='zb-columns'>
                  <div className='zb-column-is-6'>
                     <InputField
                        name={"pfemailid"}
                        id="pfemailid"
                        type = "email"
                        rules='email'
                        required = {true}
                        label={"Enter email id"}
                        hint={"Enter emailid"}
                        onChange = {(id, value) => pfemailid(value)}
                        value={storeState.pfemailid }
                     />

                  </div>

                  <div className='zb-column-is-6'>
                     <InputField
                        name={"pfcommants"}
                        id="pfcommants"
                        label={"Enter Comments"}
                        hint={"Enter comments"}
                        onChange = {(id, value) => pfcommants(value)}
                        value={storeState.pfcommants }
                     />

                  </div>

               </div>

               <div className='zb-columns'>
                  <div className='zb-column-is-6'>
                     <button type='submit' onClick = {(id, value) => pfsubmit()} className='zb-button zb-button-primary'>
                       Submit
                     </button>
                  </div>
               </div>
            </div>
         </div>
      );
   }
}
export default connect(mapStateToProps, mapDispatchToProps)(PersonalForm);
