import React, { Component } from 'react';
import { Table } from "@zambezi/sdk/table";
import {servergeturl} from '../../actions/gVariable';

class DisplayResult extends Component {
   

   constructor() {
      super();
      this.state = { data: [] };
    }

   async componentDidMount() {
      const response = await fetch(servergeturl);
      const json = await response.json();
      this.setState({ data: json.data });
      console.log('This is your data', this.state.data);
    }


         
          
   render() {

               


      return (
         <div>
            
            <Table
               className={'zb-complex-table'}
               isFlushed={false}
               isResponsive={false}
               columns={[{"key":"id", "name" : "Unique ID"}, {"key":"pffirstname", "name" : "First Name"},{"key":"pflasttname", "name" : "Last Name"},{"key":"pfemailid", "name" : "Email ID"},{"key":"pfcommants", "name" : "Comments"}]}
                  rows={this.state.data}
               >
                  
               </Table>
           
         </div>
      );
   }
}
export default DisplayResult;
