
export function increment(val) {
  console.log("ssss", val)
  return {
     type: 'INCREMENT',
     payload: val
    

  }
}
export function decrement() {
  return {
     type: 'DECREMENT'

  }
}
export function reset() {
  return { type: 'RESET'

}
}

export function pffirstname(val) {
  return {
     type: 'PFFIRSTNAME',
     payload: val
  }
}

export function pflasttname(val) {
  return {
     type: 'PFLASTTNAME',
     payload: val
  }
}

export function pfemailid(val) {
  return {
     type: 'PFEMAILID',
     payload: val
  }
}

export function pfcommants(val) {
  return {
     type: 'PFCOMMANTS',
     payload: val
  }
}

export function pfsubmit() {
  return {
     type: 'PFSUBMIT'
  }
}


export function textbox(val) {
  return {
     type: 'TEXTBOX',
     payload: val
  }
}


