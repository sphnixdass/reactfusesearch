//export const servergeturl = "http://gbmacvcsw9341:3002/api/getdata/pfdata";
//export const serverposturl = "http://gbmacvcsw9341:3002/api/pfdata";

export const servergeturl = "http://gbmacvcsw9341:3002/api/getdata/pfdata";
export const serverposturl = "http://gbmacvcsw9341:3002/api/pfdata";


