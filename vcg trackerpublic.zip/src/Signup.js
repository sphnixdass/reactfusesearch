import React, { Fragment, useRef, useState } from 'react'
import { Notification } from '@zambezi/sdk/notification'
import { Formidable, InputField } from '@zambezi/formidable-components'

const Signup = Formidable(SignupFields)

function SignupFields ({ mount }) {
  return (
    <InputField
      {...mount('Email')}
      label='Email'
      hint='This is for demonstration purposes, the form does not sign up to anything.'
      rules='email'
      errorOptions={{ arrowDirection: 'top', align: 'right' }}
    />
  )
}

function SignupForm () {
  const fields = useRef()
  const [errors, setErrors] = useState({})
  const [signedUp, setSignedUp] = useState(false)
  const errorKeys = Object.keys(errors)

  return (
    <form onSubmit={handleSubmit}>
      {errorKeys.length ? (
        <Notification
          status='error'
          title='The form contains the following errors:'
          size='small'
          withArrow
          arrowDirection='bottom'
          className='Signup-error'
        >
          <ul>
            {errorKeys.map(name => (
              <li key={name}>
                {name}: {errors[name]}
              </li>
            ))}
          </ul>
        </Notification>
      ) : null}
      {signedUp ? (
        <Notification>Thank you for subscribing!</Notification>
      ) : (
        <Fragment>
          <Signup ref={fields} />
          <button type='submit' className='zb-button zb-button-primary'>
            Subscribe
          </button>
        </Fragment>
      )}
    </form>
  )

  function handleSubmit (event) {
    const form = fields.current

    event.preventDefault()
    if (form.validate()) {
      setErrors({})
      setSignedUp(true)
    } else {
      setErrors(form.errors())
    }
  }
}

export default SignupForm
