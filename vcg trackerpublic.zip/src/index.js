import '@babel/polyfill/dist/polyfill.min'
import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import reducer from '../src/reducer/index';

//http://dp.apps.prod-pcf.lb1.rbsgrp.net/
//https://www.codegrepper.com/code-examples/typescript/Error%3A+Maximum+update+depth+exceeded.+This+can+happen+when+a+component+repeatedly+calls+setState+inside+componentWillUpdate+or+componentDidUpdate.+React+limits+the+number+of+nested+updates+to+prevent+infinite+loops.


// Prepare to work with WebSDK: http://websdk.rbsgrp.net/
import '@zambezi/sdk-themes/zb-natwest-group-standard/icons'
import '@zambezi/sdk-themes/zb-natwest-group-standard/theme.min.css'
import '@zambezi/formidable-components/dist/formidable-components.min.css'

// Load application specific parts
import './index.css'
import App from './App'
import * as serviceWorker from './serviceWorker'

const store = createStore(
    reducer,
    window.__REDUX_DEVTOOLS_EXTENSION__ && 
    window.__REDUX_DEVTOOLS_EXTENSION__()
 )
 ReactDOM.render(
    <Provider store = {store}>
       <App />
    </Provider>, document.getElementById('root')
 )

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister()
