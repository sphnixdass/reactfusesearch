const initialState = {
    isLoading: false,
    username: "dass",
    items: [],
    counter: 1,
    textbox: "",
    formtype: "",
    pffirstname: "",
    pflasttname: "",
    pfemailid: "",
    pfcommants: "",
    intputtext1 : {
       value: "",
       visible: true,
       defaultvalue: "",
       hint: "," 
    }
  };

  export default initialState;