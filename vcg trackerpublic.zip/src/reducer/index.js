import initialState  from './initialState';
import {serverposturl} from '../actions/gVariable';
const reducer = (state = initialState, action) => {
   //console.log("action value", action.payload, action.type);
    switch (action.type) {
       case 'INCREMENT': 
       return {...state, counter : state.counter + action.payload}
       case 'DECREMENT': 
       return {...state, counter : state.counter - 1}
       case 'RESET' : 
       return {...state, counter : 0}
       case 'TEXTBOX':
       return {...state, textbox : action.payload}
       case 'FORMTYPE':
       return {...state, formtype : action.payload}
       case 'PFFIRSTNAME':
       return {...state, pffirstname : action.payload}
       case 'PFLASTTNAME':
       return {...state, pflasttname : action.payload}
       case 'PFEMAILID':
       return {...state, pfemailid : action.payload}
       case 'PFCOMMANTS':
       return {...state, pfcommants : action.payload}
       case 'INTPUTTEXT1':
       return {...state, intputtext1 : action.payload}
       case 'PFSUBMIT':
         //console.log("butmit button");

                     // creates entity
            fetch(serverposturl, {
               "crossDomain": "true",
               "method": "POST",
               "headers": {
                  'Accept': 'application/json',
                  'Content-Type': 'application/json'
               },
               "body": JSON.stringify({
                  pffirstname: state.pffirstname,
                  pflasttname: state.pflasttname,
                  pfemailid: state.pfemailid,
                  pfcommants: state.pfcommants,
               })
            })
            .then(response => response.json())
            .then(response => {
              // console.log("response", response);
               //return {...state, pffirstname : "", pflasttname : "", pfemailid : "", pfcommants : ""}

            })
            .catch(err => {
               console.log(err);
            });



       return {...state, pffirstname : "", pflasttname : "", pfemailid : "", pfcommants : ""};
      

       default: return state
    }
 }
 export default reducer;